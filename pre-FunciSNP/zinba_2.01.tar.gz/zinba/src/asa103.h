extern "C"{
double digama ( double x, int *ifault );
}
void psi_values ( int *n_data, double *x, double *fx );


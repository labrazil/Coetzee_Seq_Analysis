
int netMustConnectHttps(char *hostName, int port);
/* Start https connection with server or die. */

